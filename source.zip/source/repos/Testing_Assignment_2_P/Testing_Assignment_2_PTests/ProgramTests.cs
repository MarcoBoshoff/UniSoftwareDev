﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Testing_Assignment_2_P;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing_Assignment_2_P.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void TC_1_P()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1 };
            List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_1_M1()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1 };
            List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_1_M2()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1 };
            List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_2_P()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_M1()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_M2()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEquivalent(expected, result);
        }

        [TestMethod()]
        public void TC_3_P()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72 };
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_M1()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72 };
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_M2()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72 };
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_4_P()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_M1()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_M2()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_5_P()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1 };
            List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_M1()
        {
            List<int> TC = new List<int>() { 31, -6, 95, 4, 51, -17, 12, 48, -32, -93, 99, 22, 63, -93, 25, -13, -86, -63, -5, 48 };
            List<int> expected = new List<int>() { -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_M2()
        {
            List<int> TC = new List<int>() { 31, -6, 99, 4, 51, -17, 12, 48, -32, -93, 99, 22, 63, -93, 25, -13, -86, -63, -5, 48 };
            List<int> expected = new List<int>() { -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_6_P()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99 };
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_M1()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99 };
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_M2()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99 };
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_7_P()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31 };
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_M1()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31 };
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_M2()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31 };
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_8_P()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_M1()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_M2()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_9_P()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_M1()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_M2()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_10_P()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_M1()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_M2()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
    }

    [TestClass()]
    public class MetamorphicRelation_1_Tests {
        [TestMethod()]
        public void TC_1_MR_P()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0 };
            List<int> expected = new List<int>() {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_1_MR_M1()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0 };
            List<int> expected = new List<int>() {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_1_MR_M2()
        {
            List<int> TC = new List<int>() { 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0 };
            List<int> expected = new List<int>() {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_2_MR_P()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56, -77 };
            List<int> expected = new List<int>() {-77, -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_MR_M1()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56, -77 };
            List<int> expected = new List<int>() { -77, - 76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_MR_M2()
        {
            List<int> TC = new List<int>() { -29, 46, -26, -46, -8, 38, -30, -25, 6, 37, -44, 83, -59, -48, -62, -54, 8, -76, 74, -56, -77 };
            List<int> expected = new List<int>() { -77, - 76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEquivalent(expected, result);
        }

        [TestMethod()]
        public void TC_3_MR_P()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72, -100};
            List<int> expected = new List<int>() {-100, -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_MR_M1()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72, -100 };
            List<int> expected = new List<int>() { -100, -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_MR_M2()
        {
            List<int> TC = new List<int>() { -28, 62, 47, 76, -69, -84, -71, 43, -24, -96, -64, 67, 82, 41, 56, -51, -22, -99, 72, 72, -100 };
            List<int> expected = new List<int>() { -100, -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_4_MR_P()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36, -99 };
            List<int> expected = new List<int>() { -99, -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_MR_M1()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36, -99 };
            List<int> expected = new List<int>() { -99, -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_MR_M2()
        {
            List<int> TC = new List<int>() { -98, 1, -98, -78, 11, 23, 33, 36, 7, -85, 60, 55, 69, -81, 18, -77, -11, 34, -75, -36, -99 };
            List<int> expected = new List<int>() { -99, -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_5_MR_P()
        {
            List<int> TC = new List<int>() { 31, -6, 95, 4, 51, -17, 12, 48, -32, -93, 99, 22, 63, -93, 25, -13, -86, -63, -5, 48, -94 };
            List<int> expected = new List<int>() {-94, -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_MR_M1()
        {
            List<int> TC = new List<int>() { 31, -6, 95, 4, 51, -17, 12, 48, -32, -93, 99, 22, 63, -93, 25, -13, -86, -63, -5, 48, -94 };
            List<int> expected = new List<int>() { -94, -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_MR_M2()
        {
            List<int> TC = new List<int>() { 31, -6, 95, 4, 51, -17, 12, 48, -32, -93, 99, 22, 63, -93, 25, -13, -86, -63, -5, 48, -94 };
            List<int> expected = new List<int>() { -94, -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_6_MR_P()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99, -100 };
            List<int> expected = new List<int>() {-100, -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_MR_M1()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99, -100 };
            List<int> expected = new List<int>() { -100, -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_MR_M2()
        {
            List<int> TC = new List<int>() { -55, 32, -33, 75, 52, -80, 93, 16, -27, -34, -95, -70, -89, 5, -67, -16, -23, 66, 27, -99, -100 };
            List<int> expected = new List<int>() { -100, -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_7_MR_P()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31, -98 };
            List<int> expected = new List<int>() { -98, -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_MR_M1()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31, -98 };
            List<int> expected = new List<int>() { -98, -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_MR_M2()
        {
            List<int> TC = new List<int>() { -97, -58, -73, 78, -49, -52, -66, 64, -79, -18, -97, -4, 39, 3, 58, 79, -40, 14, 71, -31, -98 };
            List<int> expected = new List<int>() {-98, -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_8_MR_P()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92, -95 };
            List<int> expected = new List<int>() {-95, -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_MR_M1()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92, -95 };
            List<int> expected = new List<int>() { -95, -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_MR_M2()
        {
            List<int> TC = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92, -95 };
            List<int> expected = new List<int>() { -95, -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_9_MR_P()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10 };
            List<int> expected = new List<int>() { -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_MR_M1()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10 };
            List<int> expected = new List<int>() { -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_MR_M2()
        {
            List<int> TC = new List<int>() { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10 };
            List<int> expected = new List<int>() {-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_10_MR_P()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30, -89 };
            List<int> expected = new List<int>() {-89, -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_MR_M1()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30, -89 };
            List<int> expected = new List<int>() { -89, -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_MR_M2()
        {
            List<int> TC = new List<int>() { 96, 96, -53, 21, -72, 73, -3, -1, 20, -14, 59, 85, -65, 97, -20, 54, -88, -15, 70, 30, -89 };
            List<int> expected = new List<int>() { -89, -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
    }
    [TestClass()]
    public class MetamorphicRelation_2_Tests
    {
        [TestMethod()]
        public void TC_1_MR_P()
    {
        List<int> TC = new List<int>() {8,7,4,10,9,10,6,6,5,5,1,2,4,8,2,3,3,1,9,7};
        List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        Sort testsort = new Sort();
        List<int> result = new List<int>();
        try
        {
            result = testsort.sort(TC);
        }
        catch (IndexOutOfRangeException) { }
        CollectionAssert.AllItemsAreUnique(result);
        CollectionAssert.AreEqual(expected, result);
    }
        [TestMethod()]
        public void TC_1_MR_M1()
    {
        List<int> TC = new List<int>() { 8, 7, 4, 10, 9, 10, 6, 6, 5, 5, 1, 2, 4, 8, 2, 3, 3, 1, 9, 7 };
        List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        Sort testsort = new Sort();
        List<int> result = new List<int>();
        try
        {
            result = testsort.M1(TC);
        }
        catch (IndexOutOfRangeException) { }
        CollectionAssert.AllItemsAreUnique(result);
        CollectionAssert.AreEqual(expected, result);
    }
        [TestMethod()]
        public void TC_1_MR_M2()
    {
        List<int> TC = new List<int>() { 8, 7, 4, 10, 9, 10, 6, 6, 5, 5, 1, 2, 4, 8, 2, 3, 3, 1, 9, 7 };
        List<int> expected = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        Sort testsort = new Sort();
        List<int> result = new List<int>();
        try
        {
            result = testsort.M2(TC);
        }
        catch (IndexOutOfRangeException) { }
        CollectionAssert.AllItemsAreUnique(result);
        CollectionAssert.AreEqual(expected, result);
    }

        [TestMethod()]
        public void TC_2_MR_P()
        {
            List<int> TC = new List<int>() {37,83,74,8,-30,46,-56,-54,-76,-8,-62,6,-44,-59,-25,-48,-46,38,-29,-26 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_MR_M1()
        {
            List<int> TC = new List<int>() { 37, 83, 74, 8, -30, 46, -56, -54, -76, -8, -62, 6, -44, -59, -25, -48, -46, 38, -29, -26 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_2_MR_M2()
        {
            List<int> TC = new List<int>() { 37, 83, 74, 8, -30, 46, -56, -54, -76, -8, -62, 6, -44, -59, -25, -48, -46, 38, -29, -26 };
            List<int> expected = new List<int>() { -76, -62, -59, -56, -54, -48, -46, -44, -30, -29, -26, -25, -8, 6, 8, 37, 38, 46, 74, 83 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEquivalent(expected, result);
        }

        [TestMethod()]
        public void TC_3_MR_P()
        {
            List<int> TC = new List<int>() {72,-51,47,-84,-99,-69,56,-22,-28,43,-71,82,-96,72,62,-24,-64,67,76,41};
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_MR_M1()
        {
            List<int> TC = new List<int>() { 72, -51, 47, -84, -99, -69, 56, -22, -28, 43, -71, 82, -96, 72, 62, -24, -64, 67, 76, 41 };
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_3_MR_M2()
        {
            List<int> TC = new List<int>() { 72, -51, 47, -84, -99, -69, 56, -22, -28, 43, -71, 82, -96, 72, 62, -24, -64, 67, 76, 41 };
            List<int> expected = new List<int>() { -99, -96, -84, -71, -69, -64, -51, -28, -24, -22, 41, 43, 47, 56, 62, 67, 72, 76, 82 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_4_MR_P()
        {
            List<int> TC = new List<int>() { -77,-98,36,-36,7,1,-11,-98,55,60,69,-75,-78,-85,23,34,18,11,33,-81 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_MR_M1()
        {
            List<int> TC = new List<int>() { -77, -98, 36, -36, 7, 1, -11, -98, 55, 60, 69, -75, -78, -85, 23, 34, 18, 11, 33, -81 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_4_MR_M2()
        {
            List<int> TC = new List<int>() { -77, -98, 36, -36, 7, 1, -11, -98, 55, 60, 69, -75, -78, -85, 23, 34, 18, 11, 33, -81 };
            List<int> expected = new List<int>() { -98, -85, -81, -78, -77, -75, -36, -11, 1, 7, 11, 18, 23, 33, 34, 36, 55, 60, 69 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_5_MR_P()
        {
            List<int> TC = new List<int>() {-17,25,-13,12,95,51,-5,63,-93,4,48,-6,-32,-86,22,99,31,48,-63,-93 };
            List<int> expected = new List<int>() { -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_MR_M1()
        {
            List<int> TC = new List<int>() { -17, 25, -13, 12, 95, 51, -5, 63, -93, 4, 48, -6, -32, -86, 22, 99, 31, 48, -63, -93 };
            List<int> expected = new List<int>() { -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 95, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_5_MR_M2()
        {
            List<int> TC = new List<int>() { -17, 25, -13, 12, 95, 51, -5, 63, -93, 4, 48, -6, -32, -86, 22, 99, 31, 48, -63, -93 };
            List<int> expected = new List<int>() { -93, -86, -63, -32, -17, -13, -6, -5, 4, 12, 22, 25, 31, 48, 51, 63, 99 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_6_MR_P()
        {
            List<int> TC = new List<int>() {-16,-95,-70,16,27,-34,93,75,5,-33,-80,52,-23,-99,-55,32,-27,66,-89,-67};
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_MR_M1()
        {
            List<int> TC = new List<int>() { -16, -95, -70, 16, 27, -34, 93, 75, 5, -33, -80, 52, -23, -99, -55, 32, -27, 66, -89, -67 };
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_6_MR_M2()
        {
            List<int> TC = new List<int>() { -16, -95, -70, 16, 27, -34, 93, 75, 5, -33, -80, 52, -23, -99, -55, 32, -27, 66, -89, -67 };
            List<int> expected = new List<int>() { -99, -95, -89, -80, -70, -67, -55, -34, -33, -27, -23, -16, 5, 16, 27, 32, 52, 66, 75, 93 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_7_MR_P()
        {
            List<int> TC = new List<int>() {79,78,-66,-79,39,64,71,3,58,-49,-4,-58,-97,-31,-73,-40,14,-97,-52,-18};
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_MR_M1()
        {
            List<int> TC = new List<int>() { 79, 78, -66, -79, 39, 64, 71, 3, 58, -49, -4, -58, -97, -31, -73, -40, 14, -97, -52, -18 };
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_7_MR_M2()
        {
            List<int> TC = new List<int>() { 79, 78, -66, -79, 39, 64, 71, 3, 58, -49, -4, -58, -97, -31, -73, -40, 14, -97, -52, -18 };
            List<int> expected = new List<int>() { -97, -79, -73, -66, -58, -52, -49, -40, -31, -18, -4, 3, 14, 39, 58, 64, 71, 78, 79 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_8_MR_P()
        {
            List<int> TC = new List<int>() { 86,15,10,-90,-7,92,13,-94,44,92,81,-43,-10,-57,-60,57,26,9,-21,-94 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_MR_M1()
        {
            List<int> TC = new List<int>() { 86, 15, 10, -90, -7, 92, 13, -94, 44, 92, 81, -43, -10, -57, -60, 57, 26, 9, -21, -94 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_8_MR_M2()
        {
            List<int> TC = new List<int>() { 86, 15, 10, -90, -7, 92, 13, -94, 44, 92, 81, -43, -10, -57, -60, 57, 26, 9, -21, -94 };
            List<int> expected = new List<int>() { -94, -90, -60, -57, -43, -21, -10, -7, 9, 10, 13, 15, 26, 44, 57, 81, 86, 92 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_9_MR_P()
        {
            List<int> TC = new List<int>() { -5,4,-2,5,0,2,9,-9,3,-7,10,1,-8,8,-6,7,-4,-1,6,-3 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_MR_M1()
        {
            List<int> TC = new List<int>() { -5, 4, -2, 5, 0, 2, 9, -9, 3, -7, 10, 1, -8, 8, -6, 7, -4, -1, 6, -3 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_9_MR_M2()
        {
            List<int> TC = new List<int>() { -5, 4, -2, 5, 0, 2, 9, -9, 3, -7, 10, 1, -8, 8, -6, 7, -4, -1, 6, -3 };
            List<int> expected = new List<int>() { -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }

        [TestMethod()]
        public void TC_10_MR_P()
        {
            List<int> TC = new List<int>() { -53,85,30,-14,-65,-88,-3,20,97,59,-15,-1,54,96,-72,70,96,-20,73,21 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.sort(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_MR_M1()
        {
            List<int> TC = new List<int>() { -53, 85, 30, -14, -65, -88, -3, 20, 97, 59, -15, -1, 54, 96, -72, 70, 96, -20, 73, 21 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M1(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
        [TestMethod()]
        public void TC_10_MR_M2()
        {
            List<int> TC = new List<int>() { -53, 85, 30, -14, -65, -88, -3, 20, 97, 59, -15, -1, 54, 96, -72, 70, 96, -20, 73, 21 };
            List<int> expected = new List<int>() { -88, -72, -65, -53, -20, -15, -14, -3, -1, 20, 21, 30, 54, 59, 70, 73, 85, 96, 97 };
            Sort testsort = new Sort();
            List<int> result = new List<int>();
            try
            {
                result = testsort.M2(TC);
            }
            catch (IndexOutOfRangeException) { }
            CollectionAssert.AllItemsAreUnique(result);
            CollectionAssert.AreEqual(expected, result);
        }
    }
}