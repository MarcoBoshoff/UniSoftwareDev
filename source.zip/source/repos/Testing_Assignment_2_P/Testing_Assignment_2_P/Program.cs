﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing_Assignment_2_P
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<int> list = new List<int>() { -94, 44, 57, 92, 81, -60, -7, 13, 10, -57, -21, 86, 26, -43, 15, -10, 9, -90, -94, 92 };
            Sort bubble = new Sort();
            List<int> output = bubble.sort(list);
            Console.Write("[ ");
            for (int i = 0; i < list.Count; i++)
            {
                if (i != list.Count - 1)
                {
                    Console.Write(list[i] + ", ");
                }
                else
                {
                    Console.Write(list[i]);
                }
            }
            Console.Write("]");


            Console.WriteLine();
            Console.Write("[ ");
            for (int i = 0; i < output.Count; i++)
            {
                if (i != output.Count - 1)
                {
                    Console.Write(output[i] + ", ");
                }
                else
                {
                    Console.Write(output[i]);
                }
            }
            Console.Write("]");
            Console.ReadLine();
        }
    }
}
