﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing_Assignment_2_P
{
    public class Sort
    {
        public List<int> sort(List<int> SI)
        {
            for (int i = 0; i < SI.Count - 1; i++)
            {
                for (int k = 0; k < SI.Count - i - 1; k++)
                {
                    if (SI[k] > SI[k + 1])
                    {
                        int temp = SI[k];
                        SI[k] = SI[k + 1];
                        SI[k + 1] = temp;
                    }
                }
            }

            for (int i = 0; i < SI.Count; i++)
            {
                for (int k = i+1; k < SI.Count; k++)
                {
                    if (SI[k] == SI[i])
                    {
                        SI.Remove(SI[k]);
                    } 
                }
            }
            return SI;
        }
        

        public List<int> M1(List<int> FI)
        {
            for (int i = 0; i < FI.Count - 1; i++)
            {
                for (int k = 0; k < FI.Count - i - 1; k++)
                {
                    if (FI[k] > FI[k + 1])
                    {
                        int temp = FI[k];
                        FI[k] = FI[k + 1];
                        FI[k + 1] = temp;
                    }
                }
            }
            for (int i = 1; i < FI.Count; i++)
            {
                for (int k = i+1; k < FI.Count; k++)
                {
                    if (FI[k] == FI[i])
                    {
                        FI.Remove(FI[k]);
                    }
                }
            }
            return FI;
        }


        public List<int> M2(List<int> FI)
        {
            for (int i = 0; i < FI.Count/2; i++)
            {
                for (int k = 0; k < FI.Count - i -1 ; k++)
                {
                    if (FI[k] > FI[k + 1])
                    {
                        int temp = FI[k];
                        FI[k] = FI[k + 1];
                        FI[k + 1] = temp;
                    }
                }
            }
            for (int i = 0; i < FI.Count; i++)
            {
                for (int k = i + 1; k < FI.Count; k++)
                {
                    if (FI[k] == FI[i])
                    {
                        FI.Remove(FI[k]);
                    }
                }
            }
            return FI;
        }
    }
}