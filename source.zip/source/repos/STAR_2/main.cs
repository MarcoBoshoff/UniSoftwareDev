﻿using System;

public class main
{
	public static void main(string[] args)
	{
        Console.WriteLine("Hello World");
	}
}
