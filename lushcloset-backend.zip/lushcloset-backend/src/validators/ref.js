// const Joi = require('joi');

module.exports = {
  getCategoryRefsSchema: {},
};
