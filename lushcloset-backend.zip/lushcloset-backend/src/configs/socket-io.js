module.exports = {
  path: '/socket',
  serveClient: false,
  cookie: false,
};
