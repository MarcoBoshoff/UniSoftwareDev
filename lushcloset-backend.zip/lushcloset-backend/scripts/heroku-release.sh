#!/bin/bash

npm run db:migrate